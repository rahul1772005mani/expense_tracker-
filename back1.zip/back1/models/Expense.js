const mongoose = require("mongoose");

const expenseSchema = new mongoose.Schema(
    {
        userId: { type: String, required: true },
        title: { type: String, required: true },
        amount: { type: Number, required: true },
        category: { type: String, required: true, default: "General" },
        type: { type: String, enum: ["income", "expense"], default: "expense" },
        description: { type: String, default: "" },
        date: { type: Date, default: Date.now },
    },
    { timestamps: true }
);

module.exports = mongoose.model("Expense", expenseSchema);