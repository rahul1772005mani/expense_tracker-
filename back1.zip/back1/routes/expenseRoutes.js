const express = require("express");
const router = express.Router();
const Expense = require("../models/Expense");
const verifyToken = require("../middleware/authMiddleware");

// ➕ Add Expense
router.post("/", verifyToken, async (req, res) => {
    try {
        const newExpense = new Expense({
            ...req.body,
            userId: req.user.uid,
        });
        const saved = await newExpense.save();
        res.json(saved);
    } catch (err) {
        res.status(500).json({ msg: err.message });
    }
});

// 📥 Get All Expenses (sorted newest first)
router.get("/", verifyToken, async (req, res) => {
    try {
        const expenses = await Expense.find({ userId: req.user.uid }).sort({ date: -1 });
        res.json(expenses);
    } catch (err) {
        res.status(500).json({ msg: err.message });
    }
});

// 📊 Get Stats (category breakdown + monthly totals)
router.get("/stats", verifyToken, async (req, res) => {
    try {
        const expenses = await Expense.find({ userId: req.user.uid });

        // Category breakdown (expenses only)
        const categoryMap = {};
        expenses.filter(e => e.type === "expense").forEach(e => {
            categoryMap[e.category] = (categoryMap[e.category] || 0) + e.amount;
        });

        // Monthly totals
        const monthlyMap = {};
        expenses.forEach(e => {
            const month = new Date(e.date).toLocaleString("default", { month: "short", year: "numeric" });
            if (!monthlyMap[month]) monthlyMap[month] = { income: 0, expense: 0 };
            monthlyMap[month][e.type] += e.amount;
        });

        res.json({ categories: categoryMap, monthly: monthlyMap });
    } catch (err) {
        res.status(500).json({ msg: err.message });
    }
});

// ✏️ Edit Expense
router.put("/:id", verifyToken, async (req, res) => {
    try {
        const updated = await Expense.findOneAndUpdate(
            { _id: req.params.id, userId: req.user.uid },
            req.body,
            { new: true }
        );
        if (!updated) return res.status(404).json({ msg: "Not found" });
        res.json(updated);
    } catch (err) {
        res.status(500).json({ msg: err.message });
    }
});

// ❌ Delete Expense
router.delete("/:id", verifyToken, async (req, res) => {
    try {
        await Expense.findOneAndDelete({ _id: req.params.id, userId: req.user.uid });
        res.json({ msg: "Deleted" });
    } catch (err) {
        res.status(500).json({ msg: err.message });
    }
});

module.exports = router;