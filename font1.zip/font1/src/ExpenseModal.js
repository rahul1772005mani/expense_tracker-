import { useState, useEffect } from "react";

const DEFAULTS = {
    title: "", amount: "", category: "Food",
    type: "expense", description: "", date: ""
};

const ExpenseModal = ({ expense, categories, onSave, onClose }) => {
    const [form, setForm] = useState(DEFAULTS);
    const [error, setError] = useState("");
    const [saving, setSaving] = useState(false);

    useEffect(() => {
        if (expense) {
            setForm({
                title: expense.title || "",
                amount: expense.amount || "",
                category: expense.category || "Food",
                type: expense.type || "expense",
                description: expense.description || "",
                date: expense.date ? expense.date.split("T")[0] : "",
            });
        } else {
            setForm({ ...DEFAULTS, date: new Date().toISOString().split("T")[0] });
        }
    }, [expense]);

    const handleChange = (e) =>
        setForm({ ...form, [e.target.name]: e.target.value });

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!form.title.trim()) { setError("Title is required."); return; }
        if (!form.amount || parseFloat(form.amount) <= 0) { setError("Enter a valid amount."); return; }
        setSaving(true);
        try {
            await onSave({
                ...form,
                amount: parseFloat(form.amount),
                date: form.date || new Date().toISOString(),
            });
        } catch (err) {
            setError("Failed to save. Please try again.");
        } finally {
            setSaving(false);
        }
    };

    return (
        <div className="modal-backdrop" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
            <div className="modal-card">
                <div className="modal-header">
                    <h2 className="modal-title">{expense ? "Edit Transaction" : "Add Transaction"}</h2>
                    <button className="modal-close" onClick={onClose}>✕</button>
                </div>

                {error && <div className="auth-error">{error}</div>}

                {/* Type Toggle */}
                <div className="type-toggle">
                    <button
                        type="button"
                        className={`type-btn ${form.type === "expense" ? "type-expense-active" : ""}`}
                        onClick={() => setForm({ ...form, type: "expense" })}
                    >
                        📤 Expense
                    </button>
                    <button
                        type="button"
                        className={`type-btn ${form.type === "income" ? "type-income-active" : ""}`}
                        onClick={() => setForm({ ...form, type: "income" })}
                    >
                        📥 Income
                    </button>
                </div>

                <form onSubmit={handleSubmit} className="modal-form">
                    <div className="modal-row">
                        <div className="form-group">
                            <label className="form-label">Title *</label>
                            <input
                                id="modal-title"
                                type="text"
                                name="title"
                                className="modal-input"
                                placeholder="e.g. Grocery shopping"
                                value={form.title}
                                onChange={handleChange}
                                required
                            />
                        </div>
                        <div className="form-group">
                            <label className="form-label">Amount (₹) *</label>
                            <input
                                id="modal-amount"
                                type="number"
                                name="amount"
                                className="modal-input"
                                placeholder="0.00"
                                min="0.01"
                                step="0.01"
                                value={form.amount}
                                onChange={handleChange}
                                required
                            />
                        </div>
                    </div>

                    <div className="modal-row">
                        <div className="form-group">
                            <label className="form-label">Category</label>
                            <select
                                id="modal-category"
                                name="category"
                                className="modal-input"
                                value={form.category}
                                onChange={handleChange}
                            >
                                {categories.map(c => (
                                    <option key={c} value={c}>{c}</option>
                                ))}
                            </select>
                        </div>
                        <div className="form-group">
                            <label className="form-label">Date</label>
                            <input
                                id="modal-date"
                                type="date"
                                name="date"
                                className="modal-input"
                                value={form.date}
                                onChange={handleChange}
                            />
                        </div>
                    </div>

                    <div className="form-group">
                        <label className="form-label">Description (optional)</label>
                        <textarea
                            id="modal-description"
                            name="description"
                            className="modal-input modal-textarea"
                            placeholder="Add a note..."
                            value={form.description}
                            onChange={handleChange}
                            rows={2}
                        />
                    </div>

                    <div className="modal-actions">
                        <button type="button" className="btn-ghost" onClick={onClose}>Cancel</button>
                        <button
                            id="modal-save"
                            type="submit"
                            className={`auth-btn modal-save-btn ${form.type === "income" ? "btn-income" : "btn-expense"}`}
                            disabled={saving}
                        >
                            {saving ? <span className="btn-spinner" /> : (expense ? "Update" : "Add Transaction")}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default ExpenseModal;
