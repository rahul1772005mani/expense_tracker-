const COLORS = [
    "#a78bfa", "#f59e0b", "#10b981", "#3b82f6",
    "#ec4899", "#ef4444", "#06b6d4", "#f97316", "#6b7280"
];

const CategoryChart = ({ categories }) => {
    const entries = Object.entries(categories);
    const total = entries.reduce((s, [, v]) => s + v, 0);

    if (entries.length === 0) {
        return (
            <div className="chart-empty">
                <span>📊</span>
                <p>No expense data yet</p>
            </div>
        );
    }

    // Build donut segments
    let cumulative = 0;
    const segments = entries.map(([cat, val], i) => {
        const pct = (val / total) * 100;
        const start = cumulative;
        cumulative += pct;
        return { cat, val, pct, start, color: COLORS[i % COLORS.length] };
    });

    // SVG donut: circumference of circle r=40 => C = 2π*40 ≈ 251.33
    const C = 251.33;
    const R = 40;
    let offset = 0;

    return (
        <div className="donut-wrap">
            <div className="donut-chart-container">
                <svg viewBox="0 0 100 100" className="donut-svg">
                    {/* Background circle */}
                    <circle cx="50" cy="50" r={R} fill="none" stroke="#1e1b4b" strokeWidth="18" />
                    {segments.map((seg, i) => {
                        const dash = (seg.pct / 100) * C;
                        const gap = C - dash;
                        const thisOffset = C - (offset / 100) * C;
                        offset += seg.pct;
                        return (
                            <circle
                                key={i}
                                cx="50" cy="50" r={R}
                                fill="none"
                                stroke={seg.color}
                                strokeWidth="18"
                                strokeDasharray={`${dash} ${gap}`}
                                strokeDashoffset={thisOffset}
                                transform="rotate(-90 50 50)"
                                className="donut-segment"
                            />
                        );
                    })}
                    <text x="50" y="46" textAnchor="middle" className="donut-label-top">Total</text>
                    <text x="50" y="58" textAnchor="middle" className="donut-label-val">
                        ₹{(total / 1000).toFixed(1)}k
                    </text>
                </svg>
            </div>

            <div className="donut-legend">
                {segments.map((seg, i) => (
                    <div key={i} className="legend-item">
                        <span className="legend-dot" style={{ background: seg.color }} />
                        <span className="legend-cat">{seg.cat}</span>
                        <span className="legend-pct">{seg.pct.toFixed(1)}%</span>
                        <span className="legend-val">₹{seg.val.toLocaleString("en-IN")}</span>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default CategoryChart;
