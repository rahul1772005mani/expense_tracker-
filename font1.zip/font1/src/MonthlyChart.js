const MonthlyChart = ({ monthly }) => {
    const entries = Object.entries(monthly);

    if (entries.length === 0) {
        return (
            <div className="chart-empty">
                <span>📅</span>
                <p>No monthly data yet</p>
            </div>
        );
    }

    // Sort by date (most recent 6 months)
    const sorted = entries
        .sort((a, b) => new Date(a[0]) - new Date(b[0]))
        .slice(-6);

    const maxVal = Math.max(...sorted.flatMap(([, v]) => [v.income || 0, v.expense || 0]), 1);

    return (
        <div className="bar-chart">
            <div className="bar-chart-grid">
                {sorted.map(([month, vals]) => (
                    <div key={month} className="bar-group">
                        <div className="bar-pair">
                            <div className="bar-col">
                                <div
                                    className="bar income-bar"
                                    style={{ height: `${((vals.income || 0) / maxVal) * 140}px` }}
                                    title={`Income: ₹${(vals.income || 0).toLocaleString("en-IN")}`}
                                />
                            </div>
                            <div className="bar-col">
                                <div
                                    className="bar expense-bar"
                                    style={{ height: `${((vals.expense || 0) / maxVal) * 140}px` }}
                                    title={`Expense: ₹${(vals.expense || 0).toLocaleString("en-IN")}`}
                                />
                            </div>
                        </div>
                        <p className="bar-label">{month.split(" ")[0]}</p>
                    </div>
                ))}
            </div>
            <div className="bar-legend">
                <span className="bl-item"><span className="bl-dot income-dot" />Income</span>
                <span className="bl-item"><span className="bl-dot expense-dot" />Expense</span>
            </div>
        </div>
    );
};

export default MonthlyChart;
