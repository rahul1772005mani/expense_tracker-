const StatsCards = ({ balance, income, expense }) => {
    const fmt = (n) => `₹${Math.abs(n).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

    return (
        <div className="stats-grid">
            <div className="stat-card stat-balance">
                <div className="stat-icon-wrap">
                    <span className="stat-icon">💰</span>
                </div>
                <div className="stat-body">
                    <p className="stat-label">Net Balance</p>
                    <p className={`stat-value ${balance >= 0 ? "stat-positive" : "stat-negative"}`}>
                        {balance >= 0 ? "" : "-"}{fmt(balance)}
                    </p>
                    <p className="stat-trend">
                        {balance >= 0 ? "✅ In the green" : "⚠️ Overspent"}
                    </p>
                </div>
            </div>

            <div className="stat-card stat-income">
                <div className="stat-icon-wrap income-icon-wrap">
                    <span className="stat-icon">📈</span>
                </div>
                <div className="stat-body">
                    <p className="stat-label">Total Income</p>
                    <p className="stat-value stat-positive">{fmt(income)}</p>
                    <p className="stat-trend">All income entries</p>
                </div>
            </div>

            <div className="stat-card stat-expense">
                <div className="stat-icon-wrap expense-icon-wrap">
                    <span className="stat-icon">📉</span>
                </div>
                <div className="stat-body">
                    <p className="stat-label">Total Expenses</p>
                    <p className="stat-value stat-negative">{fmt(expense)}</p>
                    <p className="stat-trend">All expense entries</p>
                </div>
            </div>
        </div>
    );
};

export default StatsCards;
