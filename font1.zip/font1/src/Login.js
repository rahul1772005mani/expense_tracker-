import { useState } from "react";
import { signInWithEmailAndPassword } from "firebase/auth";
import { auth } from "./firebase";

const Login = ({ onSwitchToSignup }) => {
    const [form, setForm] = useState({ email: "", password: "" });
    const [error, setError] = useState("");
    const [loading, setLoading] = useState(false);

    const handleChange = (e) =>
        setForm({ ...form, [e.target.name]: e.target.value });

    const handleLogin = async (e) => {
        e.preventDefault();
        setError("");
        setLoading(true);
        try {
            const res = await signInWithEmailAndPassword(auth, form.email, form.password);
            const token = await res.user.getIdToken();
            localStorage.setItem("token", token);
        } catch (err) {
            console.error("Firebase login error:", err.code, err.message);
            const messages = {
                "auth/invalid-credential":     "Invalid email or password.",
                "auth/user-not-found":         "No account found with this email. Please sign up first.",
                "auth/wrong-password":         "Incorrect password. Please try again.",
                "auth/invalid-email":          "Please enter a valid email address.",
                "auth/user-disabled":          "This account has been disabled.",
                "auth/too-many-requests":      "Too many failed attempts. Please try again later.",
                "auth/operation-not-allowed":  "Email/Password login is not enabled. Enable it in Firebase Console → Authentication → Sign-in method.",
                "auth/network-request-failed": "Network error. Check your internet connection.",
            };
            setError(messages[err.code] || `Login failed (${err.code})`);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="auth-page">
            <div className="auth-bg">
                <div className="auth-blob blob-1" />
                <div className="auth-blob blob-2" />
            </div>
            <div className="auth-card">
                <div className="auth-logo">
                    <span className="auth-logo-icon">💰</span>
                    <h1 className="auth-brand">ExpenseIQ</h1>
                </div>
                <h2 className="auth-title">Welcome back</h2>
                <p className="auth-subtitle">Sign in to manage your finances</p>

                {error && <div className="auth-error">{error}</div>}

                <form onSubmit={handleLogin} className="auth-form">
                    <div className="form-group">
                        <label className="form-label">Email address</label>
                        <div className="input-wrapper">
                            <span className="input-icon">✉️</span>
                            <input
                                id="login-email"
                                type="email"
                                name="email"
                                className="auth-input"
                                placeholder="you@example.com"
                                value={form.email}
                                onChange={handleChange}
                                required
                                autoComplete="email"
                            />
                        </div>
                    </div>

                    <div className="form-group">
                        <label className="form-label">Password</label>
                        <div className="input-wrapper">
                            <span className="input-icon">🔒</span>
                            <input
                                id="login-password"
                                type="password"
                                name="password"
                                className="auth-input"
                                placeholder="••••••••"
                                value={form.password}
                                onChange={handleChange}
                                required
                                autoComplete="current-password"
                            />
                        </div>
                    </div>

                    <button
                        id="login-submit"
                        type="submit"
                        className="auth-btn"
                        disabled={loading}
                    >
                        {loading ? <span className="btn-spinner" /> : "Sign In"}
                    </button>
                </form>

                <p className="auth-switch">
                    Don't have an account?{" "}
                    <button className="auth-link" onClick={onSwitchToSignup}>
                        Create account
                    </button>
                </p>
            </div>
        </div>
    );
};

export default Login;
