import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
    apiKey: "AIzaSyAVygvA0tH6GGztkYjn6ufpAssNbvAuNpI",
    authDomain: "expense-tracker-f5937.firebaseapp.com",
    projectId: "expense-tracker-f5937",
    storageBucket: "expense-tracker-f5937.firebasestorage.app",
    messagingSenderId: "561063390840",
    appId: "1:561063390840:web:06787c199524c21f65c78d",
    measurementId: "G-2X5FSKLSF2"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export default app;