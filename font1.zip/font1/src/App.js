import { useContext, useState } from "react";
import { AuthContext } from "./AuthProvider";
import Dashboard from "./Dashboard";
import Login from "./Login";
import Signup from "./Signup";

function App() {
    const { user } = useContext(AuthContext);
    const [showSignup, setShowSignup] = useState(false);

    if (user) return <Dashboard />;

    return showSignup
        ? <Signup onSwitchToLogin={() => setShowSignup(false)} />
        : <Login onSwitchToSignup={() => setShowSignup(true)} />;
}

export default App;