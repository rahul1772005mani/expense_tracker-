import { useEffect, useState, useContext, useCallback } from "react";
import axios from "axios";
import { AuthContext } from "./AuthProvider";
import ExpenseModal from "./ExpenseModal";
import StatsCards from "./StatsCards";
import CategoryChart from "./CategoryChart";
import MonthlyChart from "./MonthlyChart";

const CATEGORIES = ["Food", "Transport", "Shopping", "Health", "Entertainment", "Bills", "Education", "Travel", "Other"];
const BASE = "http://localhost:5000/api/expenses";

const Dashboard = () => {
    const { user, logout } = useContext(AuthContext);
    const [expenses, setExpenses] = useState([]);
    const [stats, setStats] = useState({ categories: {}, monthly: {} });
    const [loading, setLoading] = useState(true);
    const [modalOpen, setModalOpen] = useState(false);
    const [editExpense, setEditExpense] = useState(null);
    const [search, setSearch] = useState("");
    const [filterCategory, setFilterCategory] = useState("All");
    const [filterType, setFilterType] = useState("All");
    const [activeTab, setActiveTab] = useState("overview"); // overview | transactions
    const [deleteConfirm, setDeleteConfirm] = useState(null);
    const [sidebarOpen, setSidebarOpen] = useState(false);

    const token = localStorage.getItem("token");
    const headers = { Authorization: `Bearer ${token}` };

    const fetchData = useCallback(async () => {
        try {
            setLoading(true);
            const [expRes, statsRes] = await Promise.all([
                axios.get(BASE, { headers }),
                axios.get(`${BASE}/stats`, { headers }),
            ]);
            setExpenses(expRes.data);
            setStats(statsRes.data);
        } catch (err) {
            console.error("Fetch error:", err);
        } finally {
            setLoading(false);
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [token]);

    useEffect(() => { fetchData(); }, [fetchData]);

    const handleSave = async (formData) => {
        try {
            if (editExpense) {
                await axios.put(`${BASE}/${editExpense._id}`, formData, { headers });
            } else {
                await axios.post(BASE, formData, { headers });
            }
            setModalOpen(false);
            setEditExpense(null);
            fetchData();
        } catch (err) {
            console.error("Save error:", err);
        }
    };

    const handleDelete = async (id) => {
        try {
            await axios.delete(`${BASE}/${id}`, { headers });
            setDeleteConfirm(null);
            fetchData();
        } catch (err) {
            console.error("Delete error:", err);
        }
    };

    const openEdit = (exp) => {
        setEditExpense(exp);
        setModalOpen(true);
    };

    const openAdd = () => {
        setEditExpense(null);
        setModalOpen(true);
    };

    // Filtering
    const filtered = expenses.filter((e) => {
        const matchSearch = e.title.toLowerCase().includes(search.toLowerCase()) ||
            (e.description || "").toLowerCase().includes(search.toLowerCase());
        const matchCat = filterCategory === "All" || e.category === filterCategory;
        const matchType = filterType === "All" || e.type === filterType;
        return matchSearch && matchCat && matchType;
    });

    // Stats
    const totalIncome = expenses.filter(e => e.type === "income").reduce((s, e) => s + e.amount, 0);
    const totalExpense = expenses.filter(e => e.type === "expense").reduce((s, e) => s + e.amount, 0);
    const balance = totalIncome - totalExpense;

    const displayName = user?.displayName || user?.email?.split("@")[0] || "User";
    const initials = displayName.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2);

    return (
        <div className="dashboard-layout">
            {/* Overlay for mobile sidebar */}
            {sidebarOpen && <div className="sidebar-overlay" onClick={() => setSidebarOpen(false)} />}

            {/* Sidebar */}
            <aside className={`sidebar ${sidebarOpen ? "sidebar-open" : ""}`}>
                <div className="sidebar-header">
                    <span className="sidebar-logo-icon">💰</span>
                    <span className="sidebar-logo-text">ExpenseIQ</span>
                </div>

                <nav className="sidebar-nav">
                    <button
                        className={`nav-item ${activeTab === "overview" ? "nav-item-active" : ""}`}
                        onClick={() => { setActiveTab("overview"); setSidebarOpen(false); }}
                    >
                        <span className="nav-icon">📊</span>
                        <span>Overview</span>
                    </button>
                    <button
                        className={`nav-item ${activeTab === "transactions" ? "nav-item-active" : ""}`}
                        onClick={() => { setActiveTab("transactions"); setSidebarOpen(false); }}
                    >
                        <span className="nav-icon">📋</span>
                        <span>Transactions</span>
                    </button>
                </nav>

                <div className="sidebar-footer">
                    <div className="user-info">
                        <div className="user-avatar">{initials}</div>
                        <div className="user-details">
                            <p className="user-name">{displayName}</p>
                            <p className="user-email">{user?.email}</p>
                        </div>
                    </div>
                    <button className="logout-btn" onClick={logout} title="Logout">
                        <span>🚪</span> Logout
                    </button>
                </div>
            </aside>

            {/* Main Content */}
            <main className="dashboard-main">
                {/* Top bar */}
                <header className="topbar">
                    <div className="topbar-left">
                        <button className="hamburger" onClick={() => setSidebarOpen(!sidebarOpen)}>☰</button>
                        <div>
                            <h1 className="page-title">
                                {activeTab === "overview" ? "Overview" : "Transactions"}
                            </h1>
                            <p className="page-subtitle">
                                {new Date().toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}
                            </p>
                        </div>
                    </div>
                    <button className="add-btn" onClick={openAdd} id="add-expense-btn">
                        <span>+</span> Add Transaction
                    </button>
                </header>

                {loading ? (
                    <div className="loading-state">
                        <div className="loading-spinner large" />
                        <p>Loading your finances...</p>
                    </div>
                ) : (
                    <>
                        {/* Stats Cards */}
                        <StatsCards balance={balance} income={totalIncome} expense={totalExpense} />

                        {activeTab === "overview" && (
                            <div className="overview-grid">
                                <div className="chart-card">
                                    <h3 className="chart-title">Spending by Category</h3>
                                    <CategoryChart categories={stats.categories} />
                                </div>
                                <div className="chart-card">
                                    <h3 className="chart-title">Monthly Trend</h3>
                                    <MonthlyChart monthly={stats.monthly} />
                                </div>

                                {/* Recent Transactions */}
                                <div className="chart-card full-width">
                                    <h3 className="chart-title">Recent Transactions</h3>
                                    {expenses.slice(0, 5).length === 0 ? (
                                        <EmptyState onAdd={openAdd} />
                                    ) : (
                                        <TransactionList
                                            expenses={expenses.slice(0, 5)}
                                            onEdit={openEdit}
                                            onDelete={(id) => setDeleteConfirm(id)}
                                        />
                                    )}
                                    {expenses.length > 5 && (
                                        <button className="view-all-btn" onClick={() => setActiveTab("transactions")}>
                                            View all {expenses.length} transactions →
                                        </button>
                                    )}
                                </div>
                            </div>
                        )}

                        {activeTab === "transactions" && (
                            <div className="transactions-page">
                                {/* Filters */}
                                <div className="filters-bar">
                                    <div className="search-wrapper">
                                        <span className="search-icon">🔍</span>
                                        <input
                                            type="text"
                                            placeholder="Search transactions..."
                                            className="search-input"
                                            value={search}
                                            onChange={(e) => setSearch(e.target.value)}
                                        />
                                    </div>
                                    <select
                                        className="filter-select"
                                        value={filterType}
                                        onChange={(e) => setFilterType(e.target.value)}
                                    >
                                        <option value="All">All Types</option>
                                        <option value="income">Income</option>
                                        <option value="expense">Expense</option>
                                    </select>
                                    <select
                                        className="filter-select"
                                        value={filterCategory}
                                        onChange={(e) => setFilterCategory(e.target.value)}
                                    >
                                        <option value="All">All Categories</option>
                                        {CATEGORIES.map(c => (
                                            <option key={c} value={c}>{c}</option>
                                        ))}
                                    </select>
                                    {(search || filterCategory !== "All" || filterType !== "All") && (
                                        <button className="clear-filters" onClick={() => { setSearch(""); setFilterCategory("All"); setFilterType("All"); }}>
                                            ✕ Clear
                                        </button>
                                    )}
                                </div>

                                <div className="filter-results">
                                    {filtered.length} of {expenses.length} transactions
                                </div>

                                {filtered.length === 0 ? (
                                    <EmptyState onAdd={openAdd} filtered={true} />
                                ) : (
                                    <TransactionList
                                        expenses={filtered}
                                        onEdit={openEdit}
                                        onDelete={(id) => setDeleteConfirm(id)}
                                    />
                                )}
                            </div>
                        )}
                    </>
                )}
            </main>

            {/* Add/Edit Modal */}
            {modalOpen && (
                <ExpenseModal
                    expense={editExpense}
                    categories={CATEGORIES}
                    onSave={handleSave}
                    onClose={() => { setModalOpen(false); setEditExpense(null); }}
                />
            )}

            {/* Delete Confirmation */}
            {deleteConfirm && (
                <div className="modal-backdrop">
                    <div className="confirm-dialog">
                        <div className="confirm-icon">🗑️</div>
                        <h3>Delete Transaction?</h3>
                        <p>This action cannot be undone.</p>
                        <div className="confirm-actions">
                            <button className="btn-ghost" onClick={() => setDeleteConfirm(null)}>Cancel</button>
                            <button className="btn-danger" onClick={() => handleDelete(deleteConfirm)}>Delete</button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

// ── Sub-components ─────────────────────────────────────────────────────────────

const CATEGORY_COLORS = {
    Food: "#f59e0b", Transport: "#3b82f6", Shopping: "#ec4899",
    Health: "#10b981", Entertainment: "#8b5cf6", Bills: "#ef4444",
    Education: "#06b6d4", Travel: "#f97316", Other: "#6b7280", General: "#a78bfa"
};

const TransactionList = ({ expenses, onEdit, onDelete }) => (
    <div className="transaction-list">
        {expenses.map((exp) => {
            const color = CATEGORY_COLORS[exp.category] || "#a78bfa";
            return (
                <div key={exp._id} className="transaction-item">
                    <div className="tx-icon" style={{ background: `${color}22`, color }}>
                        {getCategoryIcon(exp.category)}
                    </div>
                    <div className="tx-info">
                        <p className="tx-title">{exp.title}</p>
                        <div className="tx-meta">
                            <span className="tx-category" style={{ background: `${color}22`, color }}>{exp.category}</span>
                            <span className="tx-date">
                                {new Date(exp.date).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}
                            </span>
                            {exp.description && <span className="tx-desc">{exp.description}</span>}
                        </div>
                    </div>
                    <div className="tx-right">
                        <p className={`tx-amount ${exp.type === "income" ? "amount-income" : "amount-expense"}`}>
                            {exp.type === "income" ? "+" : "-"}₹{exp.amount.toLocaleString("en-IN")}
                        </p>
                        <div className="tx-actions">
                            <button className="action-btn edit-btn" onClick={() => onEdit(exp)} title="Edit">✏️</button>
                            <button className="action-btn del-btn" onClick={() => onDelete(exp._id)} title="Delete">🗑️</button>
                        </div>
                    </div>
                </div>
            );
        })}
    </div>
);

const EmptyState = ({ onAdd, filtered }) => (
    <div className="empty-state">
        <div className="empty-icon">{filtered ? "🔍" : "💸"}</div>
        <h3>{filtered ? "No matching transactions" : "No transactions yet"}</h3>
        <p>{filtered ? "Try adjusting your filters." : "Add your first income or expense to get started."}</p>
        {!filtered && (
            <button className="add-btn" onClick={onAdd}>+ Add Transaction</button>
        )}
    </div>
);

const getCategoryIcon = (cat) => {
    const icons = {
        Food: "🍔", Transport: "🚗", Shopping: "🛍️", Health: "💊",
        Entertainment: "🎬", Bills: "📄", Education: "📚", Travel: "✈️",
        Other: "📌", General: "💰"
    };
    return icons[cat] || "💰";
};

export default Dashboard;