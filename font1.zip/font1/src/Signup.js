import { useState } from "react";
import { createUserWithEmailAndPassword, updateProfile } from "firebase/auth";
import { auth } from "./firebase";

const Signup = ({ onSwitchToLogin }) => {
    const [form, setForm] = useState({ name: "", email: "", password: "", confirm: "" });
    const [error, setError] = useState("");
    const [loading, setLoading] = useState(false);

    const handleChange = (e) =>
        setForm({ ...form, [e.target.name]: e.target.value });

    const handleSignup = async (e) => {
        e.preventDefault();
        setError("");
        if (form.password !== form.confirm) { setError("Passwords do not match."); return; }
        if (form.password.length < 6) { setError("Password must be at least 6 characters."); return; }
        setLoading(true);
        try {
            const res = await createUserWithEmailAndPassword(auth, form.email, form.password);
            await updateProfile(res.user, { displayName: form.name });
            const token = await res.user.getIdToken();
            localStorage.setItem("token", token);
        } catch (err) {
            console.error("Firebase signup error:", err.code, err.message);
            const messages = {
                "auth/email-already-in-use":   "An account with this email already exists.",
                "auth/weak-password":          "Password should be at least 6 characters.",
                "auth/invalid-email":          "Please enter a valid email address.",
                "auth/operation-not-allowed":  "Email/Password signup is not enabled. Enable it in Firebase Console → Authentication → Sign-in method.",
                "auth/network-request-failed": "Network error. Check your internet connection.",
            };
            setError(messages[err.code] || `Signup failed (${err.code})`);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="auth-page">
            <div className="auth-bg">
                <div className="auth-blob blob-1" />
                <div className="auth-blob blob-2" />
            </div>
            <div className="auth-card">
                <div className="auth-logo">
                    <span className="auth-logo-icon">💰</span>
                    <h1 className="auth-brand">ExpenseIQ</h1>
                </div>
                <h2 className="auth-title">Create account</h2>
                <p className="auth-subtitle">Start tracking your finances today</p>

                {error && <div className="auth-error">{error}</div>}

                <form onSubmit={handleSignup} className="auth-form">
                    <div className="form-group">
                        <label className="form-label">Full Name</label>
                        <div className="input-wrapper">
                            <span className="input-icon">👤</span>
                            <input id="signup-name" type="text" name="name" className="auth-input"
                                placeholder="John Doe" value={form.name} onChange={handleChange} required />
                        </div>
                    </div>

                    <div className="form-group">
                        <label className="form-label">Email address</label>
                        <div className="input-wrapper">
                            <span className="input-icon">✉️</span>
                            <input id="signup-email" type="email" name="email" className="auth-input"
                                placeholder="you@example.com" value={form.email} onChange={handleChange} required />
                        </div>
                    </div>

                    <div className="form-group">
                        <label className="form-label">Password</label>
                        <div className="input-wrapper">
                            <span className="input-icon">🔒</span>
                            <input id="signup-password" type="password" name="password" className="auth-input"
                                placeholder="Min. 6 characters" value={form.password} onChange={handleChange} required />
                        </div>
                    </div>

                    <div className="form-group">
                        <label className="form-label">Confirm Password</label>
                        <div className="input-wrapper">
                            <span className="input-icon">🔒</span>
                            <input id="signup-confirm" type="password" name="confirm" className="auth-input"
                                placeholder="Repeat password" value={form.confirm} onChange={handleChange} required />
                        </div>
                    </div>

                    <button id="signup-submit" type="submit" className="auth-btn" disabled={loading}>
                        {loading ? <span className="btn-spinner" /> : "Create Account"}
                    </button>
                </form>

                <p className="auth-switch">
                    Already have an account?{" "}
                    <button className="auth-link" onClick={onSwitchToLogin}>Sign in</button>
                </p>
            </div>
        </div>
    );
};

export default Signup;
